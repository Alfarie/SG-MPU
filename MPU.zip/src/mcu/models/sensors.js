var sensors = { /* ...Empty obj waiting for mcu...  */}

function UpdateSensors(s){
    sensors = s;
}

module.exports = {
    sensors
}