var freeMemory = 0;
var gpio = [0,0,0,0];
var paracc = {}

module.exports = {
    freeMemory,
    gpio,
    paracc
}